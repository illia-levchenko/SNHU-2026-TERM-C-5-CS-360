package com.levchenko.weighttracker;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputLayout;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Coordinates accessible screens, account-scoped SQLite records, and optional goal alerts. */
public class MainActivity extends AppCompatActivity {
    private static final int LOGIN = 0, WEIGHTS = 1, GOAL = 2, SMS = 3;
    private static final double POUNDS_PER_KG = 2.2046226218;
    private static final ExecutorService AUTH_EXECUTOR = Executors.newSingleThreadExecutor();
    private WeightDatabase database;
    private ViewFlipper screens;
    private long userId = -1;
    private long editingId = -1;
    private long permissionUserId = -1;
    private boolean creatingAccount;
    private boolean alertsDeclined;
    private boolean permissionRequested;
    private boolean authInFlight;
    private boolean suppressUnitChanges;
    private String goalUnit = WeightDatabase.LB;
    private Double goalDraftKg;
    private String generatedGoalText = "";

    private final ActivityResultLauncher<String> smsPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                permissionRequested = true;
                alertsDeclined = !granted;
                WeightDatabase.User account = database.getUser(permissionUserId);
                if (account != null) {
                    database.saveSmsPreferences(account.id, account.smsPhone, granted);
                    if (granted && account.id == userId) checkLatestGoal();
                }
                updateSmsStatus();
            });

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        database = new WeightDatabase(this);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        View root = findViewById(R.id.root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        WindowInsetsControllerCompat bars = new WindowInsetsControllerCompat(
                getWindow(), getWindow().getDecorView());
        bars.setAppearanceLightStatusBars(true);
        bars.setAppearanceLightNavigationBars(true);
        screens = findViewById(R.id.screens);
        screens.setInAnimation(this, android.R.anim.fade_in);
        screens.setOutAnimation(this, android.R.anim.fade_out);
        if (state != null) {
            userId = state.getLong("userId", -1);
            editingId = state.getLong("editingId", -1);
            permissionUserId = state.getLong("permissionUserId", -1);
            creatingAccount = state.getBoolean("creatingAccount");
            alertsDeclined = state.getBoolean("alertsDeclined");
            permissionRequested = state.getBoolean("permissionRequested");
        }
        if (database.getUser(userId) == null) userId = -1;
        updateAccountMode();
        findViewById(R.id.log_in_button).setOnClickListener(view -> authenticate(false));
        findViewById(R.id.create_account_button).setOnClickListener(view -> {
            if (creatingAccount) authenticate(true);
            else {
                creatingAccount = true;
                updateAccountMode();
                input(R.id.confirm_password_input).requestFocus();
            }
        });
        findViewById(R.id.goal_button).setOnClickListener(view -> showScreen(GOAL));
        findViewById(R.id.sms_button).setOnClickListener(view -> showScreen(SMS));
        findViewById(R.id.back_goal_button).setOnClickListener(view -> showScreen(WEIGHTS));
        findViewById(R.id.back_sms_button).setOnClickListener(view -> showScreen(WEIGHTS));
        findViewById(R.id.sign_out_button).setOnClickListener(view -> signOut());
        findViewById(R.id.save_goal_button).setOnClickListener(view -> saveGoal());
        findViewById(R.id.save_weight_button).setOnClickListener(view -> saveWeight());
        findViewById(R.id.cancel_edit_button).setOnClickListener(view -> resetWeightEditor());
        findViewById(R.id.date_input).setOnClickListener(view -> chooseDate());
        findViewById(R.id.allow_sms_button).setOnClickListener(view -> requestSmsPermission());
        findViewById(R.id.decline_sms_button).setOnClickListener(view -> declineSms());
        ((RadioGroup) findViewById(R.id.unit_group)).setOnCheckedChangeListener((group, checked) -> {
            if (suppressUnitChanges) return;
            String newUnit = checked == R.id.unit_kg ? WeightDatabase.KG : WeightDatabase.LB;
            if (newUnit.equals(goalUnit)) return;
            Double kilograms = readGoalKilograms(false);
            goalUnit = newUnit;
            if (kilograms != null) setGoalDraft(kilograms);
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (authInFlight) return;
                int current = screens.getDisplayedChild();
                if (current == GOAL || current == SMS) showScreen(WEIGHTS);
                else if (current == WEIGHTS && editingId > 0) resetWeightEditor();
                else if (current == WEIGHTS) signOut();
                else if (creatingAccount) {
                    creatingAccount = false;
                    updateAccountMode();
                } else finish();
            }
        });
        int restoredScreen = state == null ? LOGIN : state.getInt("screen", LOGIN);
        showScreen(userId > 0 ? restoredScreen : LOGIN);
        if (state == null) input(R.id.date_input).setText(LocalDate.now().toString());
        updateEditorButtons();
    }

    private void authenticate(boolean create) {
        if (authInFlight) return;
        String username = input(R.id.username_input).getText().toString().trim();
        String password = input(R.id.password_input).getText().toString();
        if (username.isEmpty() || username.length() > 64) {
            fieldError(R.id.username_input, R.string.username_error); return;
        }
        if (password.length() < 8 || password.length() > 256) {
            fieldError(R.id.password_input, R.string.password_error); return;
        }
        if (create && !password.equals(input(R.id.confirm_password_input).getText().toString())) {
            fieldError(R.id.confirm_password_input, R.string.password_match_error); return;
        }
        authInFlight = true;
        setAuthEnabled(false);
        hideKeyboard();
        // A separate helper keeps work safe if this activity rotates while PBKDF2 runs.
        AUTH_EXECUTOR.execute(() -> {
            long result = -1;
            String error = null;
            try (WeightDatabase workerDatabase = new WeightDatabase(getApplicationContext())) {
                result = create ? workerDatabase.createUser(username, password)
                        : workerDatabase.authenticate(username, password);
            } catch (RuntimeException exception) {
                error = exception instanceof IllegalArgumentException
                        ? exception.getMessage() : getString(R.string.storage_error);
            }
            final long authenticatedId = result;
            final String failure = error;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                authInFlight = false;
                setAuthEnabled(true);
                if (failure != null) {
                    toast(failure);
                } else if (authenticatedId <= 0) {
                    fieldError(create ? R.id.username_input : R.id.password_input,
                            create ? R.string.username_taken : R.string.login_error);
                } else {
                    userId = authenticatedId;
                    editingId = -1;
                    creatingAccount = false;
                    clearCredentials();
                    updateAccountMode();
                    resetWeightEditor();
                    showScreen(create ? GOAL : WEIGHTS);
                }
            });
        });
    }

    private void saveWeight() {
        WeightDatabase.User user = currentUser();
        if (user == null) return;
        Double kilograms = parseWeight(input(R.id.weight_input), user.preferredUnit, true);
        if (kilograms == null) return;
        String date = input(R.id.date_input).getText().toString();
        try {
            if (LocalDate.parse(date).isAfter(LocalDate.now())) {
                fieldError(R.id.date_input, R.string.future_date_error); return;
            }
            long result = database.saveWeight(userId, editingId, date, kilograms);
            if (result < 0) {
                fieldError(R.id.date_input, R.string.duplicate_date_error); return;
            }
            toast(editingId > 0 ? R.string.weight_updated : R.string.weight_saved);
            resetWeightEditor();
            refreshWeights();
            checkLatestGoal();
        } catch (DateTimeParseException exception) {
            fieldError(R.id.date_input, R.string.invalid_date_error);
        } catch (IllegalArgumentException exception) {
            toast(exception.getMessage());
        }
    }

    private void refreshWeights() {
        WeightDatabase.User user = currentUser();
        if (user == null) return;
        List<WeightDatabase.WeightEntry> entries = database.getWeights(userId);
        String unit = unitLabel(user.preferredUnit);
        ((TextInputLayout) findViewById(R.id.weight_input_container))
                .setHint(getString(R.string.weight_unit_hint, unit));
        ((TextView) findViewById(R.id.weight_header)).setText(getString(R.string.weight_unit_hint, unit));
        ((TextView) findViewById(R.id.latest_weight)).setText(entries.isEmpty()
                ? getString(R.string.no_entries) : formatWeight(entries.get(0).weightKg, user.preferredUnit));
        String goal = user.goalWeightKg == null ? getString(R.string.no_goal)
                : getString(R.string.saved_goal_summary, formatWeight(user.goalWeightKg, user.preferredUnit),
                directionLabel(user.goalDirection));
        ((TextView) findViewById(R.id.goal_summary)).setText(goal);
        findViewById(R.id.empty_history).setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
        TableLayout table = findViewById(R.id.weights_table);
        if (table.getChildCount() > 1) table.removeViews(1, table.getChildCount() - 1);
        for (WeightDatabase.WeightEntry entry : entries) {
            TableRow row = new TableRow(this);
            row.addView(tableCell(entry.date));
            row.addView(tableCell(formatNumber(fromKg(entry.weightKg, user.preferredUnit))));
            MaterialButton edit = rowButton(R.string.edit, getString(R.string.edit_entry_description, entry.date));
            edit.setOnClickListener(view -> editWeight(entry));
            row.addView(edit);
            MaterialButton delete = rowButton(R.string.delete, getString(R.string.delete_entry_description, entry.date));
            delete.setOnClickListener(view -> confirmDelete(entry));
            row.addView(delete);
            table.addView(row);
        }
    }

    private TextView tableCell(String text) {
        TextView cell = new TextView(this);
        cell.setTextAppearance(R.style.Text_WeightTracker_Cell);
        cell.setText(text);
        cell.setPadding(dp(8), dp(8), dp(8), dp(8));
        cell.setMinHeight(dp(56));
        cell.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return cell;
    }

    private MaterialButton rowButton(int label, String description) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setContentDescription(description);
        button.setTextColor(ContextCompat.getColor(this, R.color.primary));
        button.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        button.setMinWidth(dp(64));
        button.setMinimumWidth(dp(64));
        button.setMinHeight(dp(48));
        button.setPadding(dp(8), 0, dp(8), 0);
        return button;
    }

    private void editWeight(WeightDatabase.WeightEntry entry) {
        WeightDatabase.User user = currentUser();
        if (user == null) return;
        editingId = entry.id;
        input(R.id.weight_input).setText(formatNumber(fromKg(entry.weightKg, user.preferredUnit)));
        input(R.id.date_input).setText(entry.date);
        updateEditorButtons();
        input(R.id.weight_input).requestFocus();
        input(R.id.weight_input).selectAll();
    }

    private void confirmDelete(WeightDatabase.WeightEntry entry) {
        final long owner = userId;
        new MaterialAlertDialogBuilder(this).setTitle(R.string.delete_weight_title)
                .setMessage(getString(R.string.delete_weight_message, entry.date))
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    if (owner != userId || currentUser() == null) return;
                    database.deleteWeight(userId, entry.id);
                    if (editingId == entry.id) resetWeightEditor();
                    refreshWeights();
                    toast(R.string.weight_deleted);
                }).show();
    }

    private void resetWeightEditor() {
        editingId = -1;
        input(R.id.weight_input).setText("");
        input(R.id.weight_input).setError(null);
        input(R.id.date_input).setText(LocalDate.now().toString());
        input(R.id.date_input).setError(null);
        updateEditorButtons();
    }

    private void updateEditorButtons() {
        ((TextView) findViewById(R.id.save_weight_button)).setText(
                editingId > 0 ? R.string.update_weight : R.string.save_weight);
        findViewById(R.id.cancel_edit_button).setVisibility(editingId > 0 ? View.VISIBLE : View.GONE);
    }

    private void chooseDate() {
        LocalDate initial;
        try { initial = LocalDate.parse(input(R.id.date_input).getText().toString()); }
        catch (DateTimeParseException exception) { initial = LocalDate.now(); }
        DatePickerDialog picker = new DatePickerDialog(this, (view, year, month, day) -> {
            input(R.id.date_input).setText(LocalDate.of(year, month + 1, day).toString());
            input(R.id.date_input).setError(null);
        }, initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth());
        picker.getDatePicker().setMaxDate(System.currentTimeMillis());
        picker.show();
    }

    private void loadGoal() {
        WeightDatabase.User user = currentUser();
        if (user == null) return;
        suppressUnitChanges = true;
        goalUnit = user.preferredUnit;
        ((RadioGroup) findViewById(R.id.unit_group)).check(
                WeightDatabase.KG.equals(goalUnit) ? R.id.unit_kg : R.id.unit_lb);
        ((RadioGroup) findViewById(R.id.goal_type_group)).check(
                WeightDatabase.GAIN.equals(user.goalDirection) ? R.id.goal_gain
                        : WeightDatabase.MAINTAIN.equals(user.goalDirection) ? R.id.goal_maintain : R.id.goal_loss);
        suppressUnitChanges = false;
        setGoalDraft(user.goalWeightKg);
        input(R.id.target_input).setError(null);
    }

    private void setGoalDraft(Double kilograms) {
        goalDraftKg = kilograms;
        generatedGoalText = kilograms == null ? "" : formatNumber(fromKg(kilograms, goalUnit));
        input(R.id.target_input).setText(generatedGoalText);
    }

    private Double readGoalKilograms(boolean reportError) {
        String text = input(R.id.target_input).getText().toString().trim();
        if (goalDraftKg != null && text.equals(generatedGoalText)) return goalDraftKg;
        return parseWeight(input(R.id.target_input), goalUnit, reportError);
    }

    private void saveGoal() {
        if (currentUser() == null) return;
        Double kilograms = readGoalKilograms(true);
        if (kilograms == null) return;
        int checked = ((RadioGroup) findViewById(R.id.goal_type_group)).getCheckedRadioButtonId();
        String direction = checked == R.id.goal_gain ? WeightDatabase.GAIN
                : checked == R.id.goal_maintain ? WeightDatabase.MAINTAIN : WeightDatabase.LOSE;
        try {
            database.saveGoal(userId, kilograms, direction, goalUnit);
            resetWeightEditor();
            showScreen(WEIGHTS);
            toast(R.string.goal_saved);
            checkLatestGoal();
        } catch (IllegalArgumentException exception) { toast(exception.getMessage()); }
    }

    private Double parseWeight(EditText field, String unit, boolean reportError) {
        try {
            double displayed = Double.parseDouble(field.getText().toString().trim().replace(',', '.'));
            double kilograms = WeightDatabase.LB.equals(unit) ? displayed / POUNDS_PER_KG : displayed;
            if (Double.isNaN(kilograms) || Double.isInfinite(kilograms)
                    || kilograms <= 0 || kilograms > 700) throw new NumberFormatException();
            return kilograms;
        } catch (NumberFormatException exception) {
            if (reportError) {
                field.setError(getString(R.string.weight_error));
                field.requestFocus();
            }
            return null;
        }
    }

    private void requestSmsPermission() {
        WeightDatabase.User user = currentUser();
        if (user == null) return;
        String phone = input(R.id.phone_input).getText().toString().replaceAll("[\\s()\\-]", "");
        if (!phone.matches("\\+?[0-9]{3,15}")) {
            fieldError(R.id.phone_input, R.string.phone_error); return;
        }
        input(R.id.phone_input).setText(phone);
        database.saveSmsPreferences(userId, phone, false);
        permissionUserId = userId;
        alertsDeclined = false;
        if (hasSmsPermission()) {
            database.saveSmsPreferences(userId, phone, true);
            updateSmsStatus();
            checkLatestGoal();
        } else if (shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS)) {
            new MaterialAlertDialogBuilder(this).setTitle(R.string.sms_rationale_title)
                    .setMessage(R.string.sms_rationale_message)
                    .setNegativeButton(R.string.no_thanks, (dialog, which) -> declineSms())
                    .setPositiveButton(R.string.allow_sms, (dialog, which) -> {
                        if (userId == permissionUserId) smsPermission.launch(Manifest.permission.SEND_SMS);
                    }).show();
        } else smsPermission.launch(Manifest.permission.SEND_SMS);
    }

    private void declineSms() {
        WeightDatabase.User user = currentUser();
        if (user == null) return;
        // An invalid unfinished phone field must never prevent opting out.
        database.saveSmsPreferences(userId, user.smsPhone, false);
        alertsDeclined = true;
        updateSmsStatus();
        toast(R.string.alerts_off);
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updateSmsStatus() {
        if (screens == null || database == null) return;
        WeightDatabase.User user = database.getUser(userId);
        int text = R.string.sms_not_requested;
        if (user != null) {
            if (user.smsEnabled && hasSmsPermission()) text = R.string.sms_allowed;
            else if (permissionRequested && !hasSmsPermission()) text = R.string.sms_denied;
            else if (alertsDeclined || !user.smsPhone.isEmpty() || hasSmsPermission()) text = R.string.sms_opted_out;
        }
        ((TextView) findViewById(R.id.sms_status)).setText(text);
    }

    private void checkLatestGoal() {
        if (database.getUser(userId) == null) return;
        List<WeightDatabase.WeightEntry> entries = database.getWeights(userId);
        if (!entries.isEmpty()) new GoalNotifier(this, database).check(userId, entries.get(0).weightKg);
    }

    private void updateAccountMode() {
        findViewById(R.id.confirm_password_container).setVisibility(creatingAccount ? View.VISIBLE : View.GONE);
        View password = findViewById(R.id.password_input);
        password.setNextFocusForwardId(creatingAccount ? R.id.confirm_password_input : R.id.log_in_button);
        password.setNextFocusDownId(creatingAccount ? R.id.confirm_password_input : R.id.log_in_button);
        ((TextView) findViewById(R.id.create_account_button)).setText(
                creatingAccount ? R.string.continue_to_goal : R.string.create_account);
    }

    private void setAuthEnabled(boolean enabled) {
        findViewById(R.id.log_in_button).setEnabled(enabled);
        findViewById(R.id.create_account_button).setEnabled(enabled);
        ((TextView) findViewById(R.id.log_in_button)).setText(enabled ? R.string.log_in : R.string.auth_busy);
    }

    private WeightDatabase.User currentUser() {
        WeightDatabase.User user = database.getUser(userId);
        if (user == null) {
            userId = -1;
            screens.setDisplayedChild(LOGIN);
        }
        return user;
    }

    private void showScreen(int index) {
        hideKeyboard();
        if (index != LOGIN && currentUser() == null) index = LOGIN;
        if (index == WEIGHTS) refreshWeights();
        else if (index == GOAL) loadGoal();
        else if (index == SMS) {
            input(R.id.phone_input).setText(database.getUser(userId).smsPhone);
            updateSmsStatus();
        }
        screens.setDisplayedChild(index);
    }

    private void signOut() {
        userId = -1;
        editingId = -1;
        creatingAccount = false;
        alertsDeclined = false;
        permissionRequested = false;
        clearCredentials();
        input(R.id.weight_input).setText("");
        input(R.id.phone_input).setText("");
        input(R.id.target_input).setText("");
        updateAccountMode();
        updateEditorButtons();
        showScreen(LOGIN);
    }

    private void clearCredentials() {
        for (int id : new int[] { R.id.username_input, R.id.password_input, R.id.confirm_password_input }) {
            input(id).setText("");
            input(id).setError(null);
        }
    }

    private void hideKeyboard() {
        View focus = getCurrentFocus();
        if (focus != null) {
            InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            keyboard.hideSoftInputFromWindow(focus.getWindowToken(), 0);
            focus.clearFocus();
        }
    }

    private EditText input(int id) { return findViewById(id); }
    private int dp(int pixels) { return Math.round(pixels * getResources().getDisplayMetrics().density); }
    private void toast(int message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private void fieldError(int id, int message) { input(id).setError(getString(message)); input(id).requestFocus(); }
    private static double fromKg(double kilograms, String unit) {
        return WeightDatabase.LB.equals(unit) ? kilograms * POUNDS_PER_KG : kilograms;
    }
    private static String unitLabel(String unit) { return WeightDatabase.LB.equals(unit) ? "lb" : "kg"; }
    private static String formatNumber(double number) {
        return new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(Locale.US)).format(number);
    }
    private static String formatWeight(double kilograms, String unit) {
        return formatNumber(fromKg(kilograms, unit)) + " " + unitLabel(unit);
    }
    private String directionLabel(String direction) {
        return getString(WeightDatabase.GAIN.equals(direction) ? R.string.weight_gain
                : WeightDatabase.MAINTAIN.equals(direction) ? R.string.maintain_weight : R.string.weight_loss);
    }

    @Override protected void onResume() {
        super.onResume();
        if (screens != null && screens.getDisplayedChild() != LOGIN) currentUser();
        updateSmsStatus();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        state.putInt("screen", screens.getDisplayedChild());
        state.putLong("userId", userId);
        state.putLong("editingId", editingId);
        state.putLong("permissionUserId", permissionUserId);
        state.putBoolean("creatingAccount", creatingAccount);
        state.putBoolean("alertsDeclined", alertsDeclined);
        state.putBoolean("permissionRequested", permissionRequested);
        state.putString("goalUnit", goalUnit);
        state.putDouble("goalDraftKg", goalDraftKg == null ? Double.NaN : goalDraftKg);
        state.putString("generatedGoalText", generatedGoalText);
        super.onSaveInstanceState(state);
    }

    @Override protected void onRestoreInstanceState(Bundle state) {
        suppressUnitChanges = true;
        super.onRestoreInstanceState(state);
        goalUnit = state.getString("goalUnit", WeightDatabase.LB);
        double draft = state.getDouble("goalDraftKg", Double.NaN);
        goalDraftKg = Double.isNaN(draft) ? null : draft;
        generatedGoalText = state.getString("generatedGoalText", "");
        suppressUnitChanges = false;
        updateEditorButtons();
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
