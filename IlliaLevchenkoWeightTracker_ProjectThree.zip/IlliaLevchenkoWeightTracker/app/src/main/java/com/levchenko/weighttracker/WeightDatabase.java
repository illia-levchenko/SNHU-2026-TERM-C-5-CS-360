package com.levchenko.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * SQLite persistence for accounts, dated weights, and each account's preferences.
 * All measurements use kilograms internally; display conversion belongs to the UI.
 */
public final class WeightDatabase extends SQLiteOpenHelper {
    public static final String LOSE = "LOSE";
    public static final String GAIN = "GAIN";
    public static final String MAINTAIN = "MAINTAIN";
    public static final String KG = "KG";
    public static final String LB = "LB";
    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;
    private static final String[] USER_COLUMNS = {
            "id", "username", "goal_weight_kg", "goal_direction", "preferred_unit",
            "sms_phone", "sms_enabled", "goal_notified"
    };

    public WeightDatabase(Context context) {
        this(context, DATABASE_NAME);
    }

    // A separate database name lets instrumentation test persistence without touching user data.
    WeightDatabase(Context context, String databaseName) {
        super(context.getApplicationContext(), databaseName, null, DATABASE_VERSION);
    }

    @Override public void onConfigure(SQLiteDatabase database) {
        super.onConfigure(database);
        database.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE users ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "username TEXT NOT NULL COLLATE NOCASE UNIQUE,"
                + "password_hash BLOB NOT NULL, password_salt BLOB NOT NULL,"
                + "password_iterations INTEGER NOT NULL,"
                + "goal_weight_kg REAL CHECK(goal_weight_kg > 0 AND goal_weight_kg <= 700),"
                + "goal_direction TEXT NOT NULL DEFAULT 'LOSE' "
                + "CHECK(goal_direction IN ('LOSE','GAIN','MAINTAIN')),"
                + "preferred_unit TEXT NOT NULL DEFAULT 'LB' CHECK(preferred_unit IN ('KG','LB')),"
                + "sms_phone TEXT NOT NULL DEFAULT '',"
                + "sms_enabled INTEGER NOT NULL DEFAULT 0 CHECK(sms_enabled IN (0,1)),"
                + "goal_notified INTEGER NOT NULL DEFAULT 0 CHECK(goal_notified IN (0,1)))");
        database.execSQL("CREATE TABLE weights ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,"
                + "entry_date TEXT NOT NULL,"
                + "weight_kg REAL NOT NULL CHECK(weight_kg > 0 AND weight_kg <= 700),"
                + "UNIQUE(user_id,entry_date))");
    }

    @Override public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // Version 1 is the first persistence release. Add an explicit migration for future versions.
        throw new IllegalStateException("A database migration is required for this version.");
    }

    /** Returns the new ID, or -1 when that username is already registered. */
    public long createUser(String username, String password) {
        String cleanUsername = validateUsername(username);
        validatePassword(password);
        byte[] salt = PasswordHasher.newSalt();
        byte[] hash = PasswordHasher.derive(password, salt, PasswordHasher.ITERATIONS);
        ContentValues values = new ContentValues();
        values.put("username", cleanUsername);
        values.put("password_salt", salt);
        values.put("password_hash", hash);
        values.put("password_iterations", PasswordHasher.ITERATIONS);
        try {
            return getWritableDatabase().insertOrThrow("users", null, values);
        } catch (SQLiteConstraintException duplicateUsername) {
            return -1;
        }
    }

    /** Parameterized lookup followed by a constant-time password verifier comparison. */
    public long authenticate(String username, String password) {
        if (username == null || password == null || password.length() > 256) return -1;
        try (Cursor cursor = getReadableDatabase().query("users",
                new String[] { "id", "password_salt", "password_hash", "password_iterations" },
                "username = ? COLLATE NOCASE", new String[] { username.trim() },
                null, null, null)) {
            if (!cursor.moveToFirst()) return -1;
            boolean valid = PasswordHasher.matches(password, cursor.getBlob(1),
                    cursor.getInt(3), cursor.getBlob(2));
            return valid ? cursor.getLong(0) : -1;
        }
    }

    /** Returns null when a saved session refers to an account that no longer exists. */
    public User getUser(long userId) {
        if (userId <= 0) return null;
        try (Cursor cursor = getReadableDatabase().query("users", USER_COLUMNS,
                "id = ?", new String[] { Long.toString(userId) }, null, null, null)) {
            if (!cursor.moveToFirst()) return null;
            return new User(cursor.getLong(0), cursor.getString(1),
                    cursor.isNull(2) ? null : cursor.getDouble(2), cursor.getString(3),
                    cursor.getString(4), cursor.getString(5), cursor.getInt(6) == 1,
                    cursor.getInt(7) == 1);
        }
    }

    /** Creates when entryId is zero/negative, or updates an existing row owned by this user. */
    public long saveWeight(long userId, long entryId, String date, double kilograms) {
        requireUser(userId);
        validateDate(date);
        validateWeight(kilograms);
        ContentValues values = new ContentValues();
        values.put("entry_date", date);
        values.put("weight_kg", kilograms);
        SQLiteDatabase database = getWritableDatabase();
        try {
            if (entryId <= 0) {
                values.put("user_id", userId);
                return database.insertOrThrow("weights", null, values);
            }
            int changed = database.update("weights", values, "id = ? AND user_id = ?",
                    new String[] { Long.toString(entryId), Long.toString(userId) });
            if (changed != 1) throw new IllegalArgumentException("Weight entry was not found.");
            return entryId;
        } catch (SQLiteConstraintException duplicateDate) {
            return -1;
        }
    }

    public List<WeightEntry> getWeights(long userId) {
        requireUser(userId);
        List<WeightEntry> entries = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("weights",
                new String[] { "id", "entry_date", "weight_kg" }, "user_id = ?",
                new String[] { Long.toString(userId) }, null, null, "entry_date DESC, id DESC")) {
            while (cursor.moveToNext()) {
                entries.add(new WeightEntry(cursor.getLong(0), cursor.getString(1), cursor.getDouble(2)));
            }
        }
        return entries;
    }

    /** Both account and row IDs are required so one account cannot remove another's entry. */
    public boolean deleteWeight(long userId, long entryId) {
        requireUser(userId);
        return getWritableDatabase().delete("weights", "id = ? AND user_id = ?",
                new String[] { Long.toString(entryId), Long.toString(userId) }) == 1;
    }

    /** Changing the target or direction creates a fresh, eligible goal notification. */
    public void saveGoal(long userId, double kilograms, String direction, String unit) {
        User user = requireUser(userId);
        validateWeight(kilograms);
        if (!LOSE.equals(direction) && !GAIN.equals(direction) && !MAINTAIN.equals(direction)) {
            throw new IllegalArgumentException("Choose a valid goal direction.");
        }
        if (!KG.equals(unit) && !LB.equals(unit)) {
            throw new IllegalArgumentException("Choose kilograms or pounds.");
        }
        ContentValues values = new ContentValues();
        values.put("goal_weight_kg", kilograms);
        values.put("goal_direction", direction);
        values.put("preferred_unit", unit);
        // Treat tiny display-conversion roundoff as the same target.
        if (user.goalWeightKg == null || Math.abs(user.goalWeightKg - kilograms) > 0.000001
                || !direction.equals(user.goalDirection)) {
            values.put("goal_notified", 0);
        }
        getWritableDatabase().update("users", values, "id = ?",
                new String[] { Long.toString(userId) });
    }

    public void saveSmsPreferences(long userId, String phone, boolean enabled) {
        requireUser(userId);
        String cleanPhone = phone == null ? "" : phone.replaceAll("[\\s()\\-]", "");
        if (cleanPhone.length() > 32) throw new IllegalArgumentException("Phone number is too long.");
        if (enabled && !cleanPhone.matches("\\+?[0-9]{3,15}")) {
            throw new IllegalArgumentException("Enter a valid destination phone number.");
        }
        ContentValues values = new ContentValues();
        values.put("sms_phone", cleanPhone);
        values.put("sms_enabled", enabled ? 1 : 0);
        getWritableDatabase().update("users", values, "id = ?",
                new String[] { Long.toString(userId) });
    }

    /** Call only after a successful SMS result; failed attempts remain eligible for retry. */
    public void markGoalNotified(long userId) {
        requireUser(userId);
        ContentValues values = new ContentValues();
        values.put("goal_notified", 1);
        getWritableDatabase().update("users", values, "id = ?",
                new String[] { Long.toString(userId) });
    }

    private User requireUser(long userId) {
        User user = getUser(userId);
        if (user == null) throw new IllegalArgumentException("Sign in to a valid account first.");
        return user;
    }

    private static String validateUsername(String username) {
        String clean = username == null ? "" : username.trim();
        boolean hasControlCharacter = false;
        for (int index = 0; index < clean.length(); index++) {
            if (Character.isISOControl(clean.charAt(index))) hasControlCharacter = true;
        }
        if (clean.isEmpty() || clean.length() > 64 || hasControlCharacter) {
            throw new IllegalArgumentException("Username must contain 1 to 64 visible characters.");
        }
        return clean;
    }

    private static void validatePassword(String password) {
        if (password == null || password.length() < 8 || password.length() > 256) {
            throw new IllegalArgumentException("Password must contain 8 to 256 characters.");
        }
    }

    private static void validateWeight(double kilograms) {
        if (Double.isNaN(kilograms) || Double.isInfinite(kilograms)
                || kilograms <= 0 || kilograms > 700) {
            throw new IllegalArgumentException("Weight must be greater than 0 and at most 700 kg.");
        }
    }

    private static void validateDate(String date) {
        try {
            if (date == null || !date.matches("\\d{4}-\\d{2}-\\d{2}")
                    || !LocalDate.parse(date).toString().equals(date)) {
                throw new IllegalArgumentException("Use a valid date in YYYY-MM-DD format.");
            }
        } catch (DateTimeParseException invalidDate) {
            throw new IllegalArgumentException("Use a valid date in YYYY-MM-DD format.", invalidDate);
        }
    }

    public static final class User {
        public final long id;
        public final String username;
        public final Double goalWeightKg;
        public final String goalDirection;
        public final String preferredUnit;
        public final String smsPhone;
        public final boolean smsEnabled;
        public final boolean goalNotified;

        private User(long id, String username, Double goalWeightKg, String goalDirection,
                     String preferredUnit, String smsPhone, boolean smsEnabled, boolean goalNotified) {
            this.id = id;
            this.username = username;
            this.goalWeightKg = goalWeightKg;
            this.goalDirection = goalDirection;
            this.preferredUnit = preferredUnit;
            this.smsPhone = smsPhone;
            this.smsEnabled = smsEnabled;
            this.goalNotified = goalNotified;
        }
    }

    public static final class WeightEntry {
        public final long id;
        public final String date;
        public final double weightKg;

        private WeightEntry(long id, String date, double weightKg) {
            this.id = id;
            this.date = date;
            this.weightKg = weightKg;
        }
    }
}
