package com.levchenko.weighttracker;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/** Receives the explicit modem callback even if the screen was recreated or the app was closed. */
public final class GoalSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        long userId = intent.getLongExtra("userId", -1);
        if (userId <= 0) return;
        context.getSharedPreferences("pending_goal_sms", Context.MODE_PRIVATE).edit()
                .remove(Long.toString(userId)).apply();
        boolean sent = getResultCode() == Activity.RESULT_OK;
        if (sent) {
            try (WeightDatabase database = new WeightDatabase(context)) {
                WeightDatabase.User user = database.getUser(userId);
                // An old callback must not mark a newly edited goal as already notified.
                if (user != null && user.goalWeightKg != null
                        && Double.compare(user.goalWeightKg, intent.getDoubleExtra("goalKg", -1)) == 0
                        && user.goalDirection.equals(intent.getStringExtra("direction"))) {
                    database.markGoalNotified(userId);
                }
            }
        }
        Toast.makeText(context, sent ? R.string.sms_sent : R.string.sms_failed, Toast.LENGTH_LONG).show();
    }
}
