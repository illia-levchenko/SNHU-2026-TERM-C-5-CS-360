package com.levchenko.weighttracker;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

/** Sends one opt-in SMS per saved goal; normal tracking never depends on SMS availability. */
public final class GoalNotifier {
    private final Context context;
    private final WeightDatabase database;

    public GoalNotifier(Context context, WeightDatabase database) {
        this.context = context.getApplicationContext();
        this.database = database;
    }

    public static boolean goalReached(double weightKg, double goalKg, String direction) {
        if (!Double.isFinite(weightKg) || !Double.isFinite(goalKg) || weightKg <= 0 || goalKg <= 0) return false;
        if (WeightDatabase.LOSE.equals(direction)) return weightKg <= goalKg;
        if (WeightDatabase.GAIN.equals(direction)) return weightKg >= goalKg;
        return WeightDatabase.MAINTAIN.equals(direction) && Math.abs(weightKg - goalKg) <= 0.25;
    }

    public static boolean shouldSend(WeightDatabase.User user, boolean permission, double weightKg) {
        return user != null && permission && user.smsEnabled && !user.goalNotified
                && user.goalWeightKg != null && !user.smsPhone.isEmpty()
                && goalReached(weightKg, user.goalWeightKg, user.goalDirection);
    }

    public void check(long userId, double latestWeightKg) {
        WeightDatabase.User user = database.getUser(userId);
        boolean permission = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
        if (!shouldSend(user, permission, latestWeightKg)) return;
        SharedPreferences pending = context.getSharedPreferences("pending_goal_sms", Context.MODE_PRIVATE);
        String key = Long.toString(userId);
        long lastAttempt = pending.getLong(key, 0);
        // Suppress repeated taps while the modem reports a result. A failed or timed-out send can retry.
        if (System.currentTimeMillis() - lastAttempt < 60000) return;
        String feature = Build.VERSION.SDK_INT >= 33 ? PackageManager.FEATURE_TELEPHONY_MESSAGING
                : PackageManager.FEATURE_TELEPHONY;
        if (!context.getPackageManager().hasSystemFeature(feature)) {
            Toast.makeText(context, R.string.sms_unavailable, Toast.LENGTH_LONG).show();
            return;
        }
        Intent result = new Intent(context, GoalSmsReceiver.class)
                .setAction(context.getPackageName() + ".GOAL_SMS_SENT." + userId)
                .putExtra("userId", userId).putExtra("goalKg", user.goalWeightKg)
                .putExtra("direction", user.goalDirection);
        PendingIntent sent = PendingIntent.getBroadcast(context, (int) userId, result,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        pending.edit().putLong(key, System.currentTimeMillis()).apply();
        try {
            SmsManager manager = Build.VERSION.SDK_INT >= 31 ? context.getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            if (manager == null) throw new UnsupportedOperationException("SMS service unavailable");
            // Keep the alert within one SMS and avoid exposing a measurement on the lock screen.
            manager.sendTextMessage(user.smsPhone, null,
                    "Weight Tracker: You reached your saved weight goal. Open the app to view your progress.", sent, null);
        } catch (RuntimeException error) {
            pending.edit().remove(key).apply();
            Toast.makeText(context, R.string.sms_failed, Toast.LENGTH_LONG).show();
        }
    }
}
